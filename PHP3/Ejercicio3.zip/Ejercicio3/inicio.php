<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 3</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <h1>Menú de opciones</h1>
    </header>
    <main>
        <ul>
            <li><a href="procesar.php?opcion=1">Mostrar array</a></li>
            <li><a href="procesar.php?opcion=2">Ordenar array</a></li>
            <li><a href="procesar.php?opcion=3">Mostrar numero de elementos array</a></li>
            <li><a href="procesar.php?opcion=4">Mostrar menú de nuevo</a></li>
        </ul>
    </main>

</body>

</html>